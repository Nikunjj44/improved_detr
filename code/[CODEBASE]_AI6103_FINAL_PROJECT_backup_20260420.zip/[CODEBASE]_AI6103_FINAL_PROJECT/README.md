# AI6103 Deep Learning and Applications

## Final Project: Improved DETR with Conditional Cross-Attention for Faster Convergence and Better Localization

### Team Members

| Name | Student ID | Email |
|---|---|---|
| He Weinan | G2503102K | WEINAN002@e.ntu.edu.sg |
| Wong De Shun | G2504737D | DESHUN001@e.ntu.edu.sg |
| Madan Nikunj | G2504045E | NIKUNJ005@e.ntu.edu.sg |

### Data

We train and evaluate both the baseline DETR and the improved DETR on the PASCAL VOC image sets. The training split combines VOC2007 trainval and VOC2012 trainval (about 16,551 images) and the validation split uses VOC2007 test (about 4,952 images), across 20 object classes.

### Data Pipeline

VOC XMLs → `scripts/voc2coco.py` → COCO JSON → `CocoDetection` → DETR training.

Download VOC2007 and VOC2012 into `data/VOCdevkit/VOC2007` and `data/VOCdevkit/VOC2012`, then run `python scripts/voc2coco.py`. The converted dataset is written to `data/voc_coco_format/` with `train2017/`, `val2017/`, and `annotations/` subdirectories as expected by the dataloader.


### How to Run

Install dependencies with `pip install -r requirements.txt`. A recent PyTorch with CUDA support is required; the reported results were produced with PyTorch 2.10 on an RTX PRO 6000 GPU.

To train the baseline DETR:

```
python baseline_detr/main.py --batch_size 16 --num_queries 50 --epochs 200 --lr_drop 120 --coco_path data/voc_coco_format --output_dir outputs/baseline
```

To train the improved DETR:

```
python improved_detr/main.py --batch_size 16 --num_queries 50 --epochs 75 --lr_drop 40 --coco_path data/voc_coco_format --output_dir outputs/improved --conditional
```

The `notebooks/` directory contains the Colab notebooks that were used to produce the reported training runs on Google Drive-mounted data and outputs, included for reference and reproducibility.
